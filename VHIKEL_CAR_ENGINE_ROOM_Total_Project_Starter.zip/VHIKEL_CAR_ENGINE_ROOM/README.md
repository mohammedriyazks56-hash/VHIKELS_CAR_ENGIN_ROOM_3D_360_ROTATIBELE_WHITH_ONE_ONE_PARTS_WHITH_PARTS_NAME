# VHIKEL CAR ENGINE ROOM — starter source project

This ZIP contains the initial Flutter source project.

Included:
- Flutter app structure for Android and iOS
- Home screen, vehicle search and category filters
- Sample vehicle records and detail pages
- Engine and gearbox learning topic sections
- 3D viewer placeholder and model asset folder
- A–Z development roadmap

Not yet included:
- A complete worldwide vehicle database
- Finished 3D vehicle, engine and gearbox GLB models
- Working removable-part/exploded-view system
- Cloud database, user accounts or sync
- Advertising integration
- Store-ready APK/AAB or iOS build

These require further development, model assets, testing and licensing.

To run: install Flutter and Android SDK, run `flutter pub get`, then `flutter run`.
iOS builds require macOS/Xcode or a supported cloud build service.
