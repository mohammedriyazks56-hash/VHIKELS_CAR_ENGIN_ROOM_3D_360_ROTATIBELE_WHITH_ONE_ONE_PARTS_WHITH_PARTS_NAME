import 'package:flutter/material.dart';
void main() => runApp(const VhikelApp());

class VhikelApp extends StatelessWidget {
  const VhikelApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'VHIKEL CAR ENGINE ROOM',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFFB51F2D)), useMaterial3: true),
    home: const HomePage(),
  );
}

class Vehicle {
  final String name, category, engine, gearbox, notes;
  const Vehicle(this.name, this.category, this.engine, this.gearbox, this.notes);
}

const vehicles = [
  Vehicle('Toyota Fortuner 2.8 Diesel 4WD', 'Cars & SUVs', '1GD-FTV, 2,755 cc, 4-cylinder turbo diesel', '6-speed automatic + 4WD transfer case', 'Prototype reference; exact specifications vary by year and market.'),
  Vehicle('Honda CBR650R', 'Motorcycles', '649 cc inline-four petrol', '6-speed manual', 'Sample record; verify exact model year.'),
  Vehicle('Volvo FH16 780', 'Heavy trucks', '17.3 L D17 diesel (version dependent)', 'I-Shift automated manual (configuration dependent)', 'Sample record; verify exact configuration.'),
  Vehicle('Electric vehicle example', 'Electric vehicles', 'Electric traction motor(s)', 'Usually single-speed reduction drive', 'EVs do not use a conventional combustion engine.'),
];

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}
class _HomePageState extends State<HomePage> {
  String query = '', category = 'All';
  final categories = ['All','Cars & SUVs','Motorcycles','Scooters','Buses','Heavy trucks','Electric vehicles','Hybrid vehicles'];
  @override
  Widget build(BuildContext context) {
    final shown = vehicles.where((v) =>
      (category == 'All' || v.category == category) &&
      ('${v.name} ${v.engine} ${v.gearbox}'.toLowerCase().contains(query.toLowerCase()))).toList();
    return Scaffold(
      appBar: AppBar(title: const Text('VHIKEL CAR ENGINE ROOM')),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: const Color(0xFF17191F), borderRadius: BorderRadius.circular(18)), child: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('EXPLORE EVERY ENGINE IN 3D', style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: 20)),
          SizedBox(height: 8), Text('Worldwide vehicles • Engines • Gearboxes • Drivetrains', style: TextStyle(color: Colors.white70)),
        ])),
        const SizedBox(height: 16),
        TextField(decoration: const InputDecoration(prefixIcon: Icon(Icons.search), hintText: 'Search vehicle, engine code or gearbox', border: OutlineInputBorder()), onChanged: (v) => setState(() => query = v)),
        const SizedBox(height: 12),
        SizedBox(height: 44, child: ListView(scrollDirection: Axis.horizontal, children: categories.map((c) => Padding(padding: const EdgeInsets.only(right: 8), child: ChoiceChip(label: Text(c), selected: category == c, onSelected: (_) => setState(() => category = c)))).toList())),
        const SizedBox(height: 16),
        const Text('Vehicle library', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        ...shown.map((v) => Card(child: ListTile(leading: const CircleAvatar(child: Icon(Icons.precision_manufacturing)), title: Text(v.name), subtitle: Text('${v.engine}\n${v.gearbox}', maxLines: 2, overflow: TextOverflow.ellipsis), isThreeLine: true, trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => VehiclePage(vehicle: v)))))),
        if (shown.isEmpty) const Text('No matching sample vehicles yet.'),
        const SizedBox(height: 20),
        const Text('App modules', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
        const ListTile(leading: Icon(Icons.view_in_ar), title: Text('3D engine explorer'), subtitle: Text('360° rotation and zoom when a GLB model is added')),
        const ListTile(leading: Icon(Icons.settings), title: Text('Gearbox explorer'), subtitle: Text('Manual, automatic, CVT, DCT and truck transmissions')),
        const ListTile(leading: Icon(Icons.build), title: Text('Parts and maintenance'), subtitle: Text('Component explanations and maintenance learning')),
        const ListTile(leading: Icon(Icons.public), title: Text('Worldwide vehicle database'), subtitle: Text('Designed for year- and market-specific records')),
      ]),
    );
  }
}

class VehiclePage extends StatelessWidget {
  final Vehicle vehicle;
  const VehiclePage({super.key, required this.vehicle});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(vehicle.name)),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      const Text('3D engine and gearbox explorer', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold)),
      Container(height: 280, margin: const EdgeInsets.symmetric(vertical: 12), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)), child: const Center(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        Icon(Icons.view_in_ar, size: 60), SizedBox(height: 12),
        Text('3D GLB model not installed yet', style: TextStyle(fontWeight: FontWeight.bold)),
        Padding(padding: EdgeInsets.all(12), child: Text('Add a licensed, optimized model to enable 360° viewing.', textAlign: TextAlign.center)),
      ]))),
      _info('Engine', vehicle.engine), _info('Gearbox / drivetrain', vehicle.gearbox), _info('Notes', vehicle.notes),
      const SizedBox(height: 12), const Text('Learning sections', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      for (final t in ['Engine construction and operation','Fuel, air intake and exhaust','Cooling and lubrication','Turbocharger and injection','Gearbox construction and operation','Drivetrain and differential','Maintenance and troubleshooting','Model-year and country differences'])
        Card(child: ListTile(leading: const Icon(Icons.menu_book), title: Text(t))),
      const Text('Prototype limitation: finished 3D assets and removable component interactions are not included. These require licensed GLB models with separately named meshes and additional viewer code.'),
    ]),
  );
  Widget _info(String title, String value) => Card(child: ListTile(title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text(value)));
}
