# VHIKEL A–Z development roadmap

A. App name, logo and identity.
B. Vehicle categories: cars, SUVs, bikes, scooters, buses, vans, trucks, EVs and hybrids.
C. Vehicle data fields: maker, model, year, market, engine code, gearbox, drivetrain.
D. Screen design and navigation.
E. Flutter project setup for Android and iOS.
F. Create or license optimized 3D vehicle and powertrain models.
G. Add 360° rotation, zoom, pan and reset.
H. Separate engine components into named meshes.
I. Add gearbox, clutch/torque converter and transfer-case models.
J. Add part selection, hide/show, exploded view and reassembly.
K. Build verified engine specifications database.
L. Add engine working animations and lessons.
M. Add gearbox types and transmission lessons.
N. Add maintenance and troubleshooting with source references.
O. Store year- and country-specific variants.
P. Add search.
Q. Add comparison.
R. Add favourites.
S. Add offline selected content.
T. Add languages and accessibility.
U. Test Android phones at different performance levels.
V. Optimize 3D models, textures and downloads.
W. Test iPhone and iPad.
X. Prepare store listing, privacy policy, licenses and releases.
Y. Add advertising, consent and analytics.
Z. Expand worldwide and maintain data quality.

First prototype: Toyota Fortuner 2.8 diesel 4WD, 1GD-FTV engine, 6-speed automatic and transfer case. Specifications vary by year and market.
